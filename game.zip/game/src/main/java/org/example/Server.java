package org.example;

import org.example.model.*;
import org.example.utils.SenderClient;
import org.example.utils.Utility;

import java.io.*;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Server extends Thread{
    private static final int DOMANDE = 2; //TODO: FARLO DEFINIRE DA UTENTE O LASCIARLO DI DEFAULT
    private static final String QUESTION_FILE = "./questions.txt";
    private final Socket s;
    private Match match;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private Player player;
    private Memory<Match> matchesSaved;
    private Memory<Match> matchesList;
    private Memory<Player> usersConnected;

    private SenderClient senderClient;
    private boolean flag;
    public Server(Socket s, Memory<Match> matchesSaved, Memory<Match> matchesList, Memory<Player> usersConnected){
        this.s = s;
        this.match = null;
        this.player = new Player();
        this.flag = false;
        this.matchesSaved = matchesSaved;
        this.matchesList = matchesList;
        this.usersConnected = usersConnected;
        try{
            this.in = new ObjectInputStream(this.s.getInputStream());
            this.out = new ObjectOutputStream(this.s.getOutputStream());
            this.senderClient = new SenderClient(this.in, this.out);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void run() {
        this.read();
    }

    private void read(){
        try{
            while (!flag){
                Message mex = (Message) this.in.readObject();
                if(mex != null){ //TODO: CHECK IF MEX IS A REAL MESSAGE
                    System.out.println("Client entered: "+mex);
                    switch (mex.getEvent()){
                        case "NAME":
                            this.player.setName(mex.getOwner());
                            this.usersConnected.add(this.player);
                            this.match = this.checkPreviousMatches();
                            if(this.match != null){ //HO UN MATCH NON FINITO DA POTER FINIRE
                                this.senderClient.sendToClient(mex,"mode",this.match.type);
                            }else{
                                this.senderClient.sendToClient(mex,"mode");
                            }
                            break;
                        case "START":
                            handleStartGame(mex);
                            break;
                        case "GAME":
                            handleGaming(mex);
                            break;
                        case "END":
                            handleClosing(mex);
                            break;
                        case "REMOVE":
                            handleRemove(mex);
                            break;
                        case "RESUME":
                            handleContinueGame(mex);
                            break;
                        case "NAME_CHECKER":
                            handleNameChecker(mex);
                            break;
                        case "CREATE":
                            handleCreate(mex);
                            break;
                        case "MATCH_REMOVER":
                            handleRemover(mex);
                            break;
                        case "FRIENDLY_START":
                            handleFriendlyStartGame(mex);
                            break;
                        case "GET_IN":
                            handleGetIn(mex);
                            break;
                    }
                }
            }
        }
        catch (Exception ee){
            ee.printStackTrace();
        }
    }

    private void handleGetIn(Message mex){
    if(mex.getMessage() != null){
        String nameGot = (String) mex.getMessage();
        Match mm = new Match("friendly",nameGot,null);
        Match m = this.matchesList.get(mm);
        if(m != null){
            this.match = m;
            this.match.addPlayer(this.player);
            this.senderClient.sendToClient(mex,"GET_IN",m);
        }
    }
    }
    /**
     * Metodo usato per la gestione di un match di tipo practice
     * */
    private void handleGaming(Message mex){
        player.score.addQuestion((Question) mex.getMessage());
        if(player.hasQuestion()){
            Question q = player.pickQuestion();
            if(q != null){
                this.senderClient.sendToClient(mex,"game",q);
            }
        }else{
            this.senderClient.sendToClient(mex,"end",player.score);
            player.score.questions.clear();
            this.match = null;
        }
    }

    /**
     * Metodo usato per la gestione della scelta del tipo di match da interfaccia ModeView
     * */
    private void handleStartGame(Message mex){
        try{
            Utility.readQuestionsFromFile(QUESTION_FILE, this.player, DOMANDE);
            switch(mex.getMessage().toString().toLowerCase()){
                case "practice":
                    this.match = new Match("practice", this.player);
                    this.match.addPlayer(this.player);
                    this.matchesList.add(this.match);
                    Question q = player.pickQuestion();
                    if(q != null){
                        this.senderClient.sendToClient(mex,"game",q);
                    }
                    break;
                case "friendly":
                    ArrayList<Match> matches = this.matchesList.clone();
                    ArrayList<Match> available = new ArrayList<>();
                    for(Match m : matches){
                        if(m.available && m.type.equals("friendly"))
                            available.add(m);
                    }
                    this.senderClient.sendToClient(mex,"list",available);
                    break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    private void handleFriendlyStartGame(Message mex){

    }
    private void handleNameChecker(Message mex){
        try{
            String nameMatch = (String) mex.getMessage();
            if(nameMatch != null && nameMatch.length() > 0){
                Match m = new Match("friendly",nameMatch, this.player);
                boolean result = matchesList.checkElement(m);
                if(result){
                    this.senderClient.sendToClient(mex,"NAME_CHECKER","Y");
                }else{
                    this.senderClient.sendToClient(mex,"NAME_CHECKER");
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void handleContinueGame(Message mex){
        try{
            switch(mex.getMessage().toString().toLowerCase()){
                case "practice":
                    this.matchesSaved.remove(this.match);
                    this.player.score = this.match.getPlayer(mex.getOwner()).score;
                    this.matchesList.add(this.match);
                    this.player.questions = this.getPreviousQuestions(this.player.name, this.match);
                    Question q = this.player.pickQuestion();
                    if(q != null){
                        this.senderClient.sendToClient(mex,"game",q);
                    }
                    break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    /**
     * Metodo usato per la rimozione di un match salvato e non terminato
     * */
    private void handleRemove(Message mex){
        this.matchesSaved.remove(this.match);
        this.match = null;
        this.senderClient.sendToClient(mex,"remove","Done");

    }

    /**
     * Metodo usato per gestire la chiusura di una connessione con client
     * */
    private void handleClosing(Message mex){
        System.out.println("Closing the connection");
        if(mex.getMessage() != null && this.match != null){
            MatchChecker mm = (MatchChecker) mex.getMessage();
            this.match.getPlayer(mex.getOwner()).questions.add(mm.getQuestion());
            this.matchesList.remove(this.match);
            matchesSaved.add(this.match);//TODO: E SE IL MATCH FOSSE FRIENDLY O TOURNAMENT COME LO TRATTO?

        }
        this.senderClient.sendToClient(mex,"end","End!");
        try{
            this.s.close();
            this.in.close();
            this.out.close();
            this.flag = true;
            this.usersConnected.remove(this.player);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Metodo usato per la creazione di match di tipo friendly
     * */
    private void handleCreate(Message mex){
        try{
            this.match = new Match("friendly", (String) mex.getMessage(), this.player);
            this.match.addPlayer(this.player);
            this.match.available = true;
            this.matchesList.add(this.match);
            this.senderClient.sendToClient(mex,"create",this.match);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Metodo usato per la rimozione di un match in corso o in attesa di essere avviato
     * */
    private void handleRemover(Message mex){
        this.matchesList.remove(this.match);
        this.match = null;
        this.senderClient.sendToClient(mex,"MATCH_REMOVER","ok");
    }

    /**
     * Metodo usato per controllare se ci sono match in precedenza non terminati del mio player
     * */
    private synchronized Match checkPreviousMatches(){
        for(Match m : this.matchesSaved.memory){
            if((m.type.equals("practice")) && m.containsUser(this.player)){
                return m;
            }
        }
        return null;
    }

    private ArrayList<Question> getPreviousQuestions(String name, Match m){
        Player p = m.getPlayer(name);
        if(p != null){
            return p.questions;
        }
        return null;
    }
}
